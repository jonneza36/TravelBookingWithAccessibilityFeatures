import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { ArrowRight } from "lucide-react"

export function EquipmentRental() {
  return (
    <section className="py-12">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center text-center space-y-4 mb-10">
          <h2 className="text-2xl md:text-3xl font-bold tracking-tighter">Specialized Equipment Rental</h2>
          <p className="text-muted-foreground max-w-[700px]">
            Rent mobility and accessibility equipment for your trip, delivered directly to your accommodation.
          </p>
        </div>

        <Tabs defaultValue="mobility" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="mobility">Mobility Equipment</TabsTrigger>
            <TabsTrigger value="bathroom">Bathroom Aids</TabsTrigger>
            <TabsTrigger value="bedroom">Bedroom Aids</TabsTrigger>
          </TabsList>
          <TabsContent value="mobility" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <EquipmentCard
                title="Manual Wheelchair"
                image="/placeholder.svg?height=200&width=200"
                price="$25"
                description="Lightweight, foldable manual wheelchair suitable for daily use."
                features={["Foldable", "18-inch seat", "Weight capacity: 250 lbs"]}
              />
              <EquipmentCard
                title="Power Wheelchair"
                image="/placeholder.svg?height=200&width=200"
                price="$75"
                description="Electric wheelchair with joystick control and long battery life."
                features={["Joystick control", "20-mile range", "Weight capacity: 300 lbs"]}
              />
              <EquipmentCard
                title="Mobility Scooter"
                image="/placeholder.svg?height=200&width=200"
                price="$60"
                description="Portable mobility scooter ideal for outdoor excursions and sightseeing."
                features={["Disassembles for transport", "15-mile range", "Basket included"]}
              />
            </div>
          </TabsContent>
          <TabsContent value="bathroom" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <EquipmentCard
                title="Shower Chair"
                image="/placeholder.svg?height=200&width=200"
                price="$15"
                description="Adjustable height shower chair with non-slip feet."
                features={["Adjustable height", "Non-slip feet", "Weight capacity: 300 lbs"]}
              />
              <EquipmentCard
                title="Toilet Riser"
                image="/placeholder.svg?height=200&width=200"
                price="$12"
                description="Raised toilet seat with handles for easier transfers."
                features={["3-inch rise", "Secure attachment", "Built-in handles"]}
              />
              <EquipmentCard
                title="Bath Transfer Bench"
                image="/placeholder.svg?height=200&width=200"
                price="$20"
                description="Transfer bench for safe bathtub entry and exit."
                features={["Adjustable height", "Reversible", "Suction cup feet"]}
              />
            </div>
          </TabsContent>
          <TabsContent value="bedroom" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <EquipmentCard
                title="Bed Rail"
                image="/placeholder.svg?height=200&width=200"
                price="$18"
                description="Adjustable bed rail to assist with getting in and out of bed."
                features={["Adjustable height", "Folds down", "Universal fit"]}
              />
              <EquipmentCard
                title="Overbed Table"
                image="/placeholder.svg?height=200&width=200"
                price="$22"
                description="Adjustable height overbed table for eating and activities."
                features={["Height adjustable", "Tilting surface", "Side pocket"]}
              />
              <EquipmentCard
                title="Patient Lift"
                image="/placeholder.svg?height=200&width=200"
                price="$85"
                description="Hydraulic patient lift for safe transfers between bed and chair."
                features={["Hydraulic operation", "Includes sling", "Weight capacity: 400 lbs"]}
              />
            </div>
          </TabsContent>
        </Tabs>

        <div className="mt-12 bg-slate-50 rounded-lg p-6 md:p-8">
          <div className="grid md:grid-cols-2 gap-6 items-center">
            <div>
              <h3 className="text-xl font-bold mb-2">Equipment Delivery Service</h3>
              <p className="text-muted-foreground mb-4">
                We deliver and set up all equipment directly at your accommodation before you arrive, and pick it up
                after your departure.
              </p>
              <ul className="space-y-2 mb-6">
                <li className="flex items-center gap-2">
                  <Badge variant="outline" className="rounded-full h-6 w-6 p-0 flex items-center justify-center">
                    ✓
                  </Badge>
                  <span>Delivery to any accommodation</span>
                </li>
                <li className="flex items-center gap-2">
                  <Badge variant="outline" className="rounded-full h-6 w-6 p-0 flex items-center justify-center">
                    ✓
                  </Badge>
                  <span>Professional setup and instructions</span>
                </li>
                <li className="flex items-center gap-2">
                  <Badge variant="outline" className="rounded-full h-6 w-6 p-0 flex items-center justify-center">
                    ✓
                  </Badge>
                  <span>24/7 technical support</span>
                </li>
                <li className="flex items-center gap-2">
                  <Badge variant="outline" className="rounded-full h-6 w-6 p-0 flex items-center justify-center">
                    ✓
                  </Badge>
                  <span>Sanitized equipment guaranteed</span>
                </li>
              </ul>
              <Button className="gap-2">
                Learn More About Equipment Rental
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
            <div className="relative h-64 md:h-full">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="Equipment delivery service"
                fill
                className="object-cover rounded-lg"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

function EquipmentCard({
  title,
  image,
  price,
  description,
  features,
}: {
  title: string
  image: string
  price: string
  description: string
  features: string[]
}) {
  return (
    <Card className="overflow-hidden">
      <div className="relative h-48 flex items-center justify-center bg-slate-50 p-6">
        <Image src={image || "/placeholder.svg"} alt={title} width={150} height={150} className="object-contain" />
      </div>
      <CardHeader className="p-4">
        <CardTitle className="text-lg">{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <ul className="space-y-1">
          {features.map((feature, index) => (
            <li key={index} className="text-sm flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-primary" />
              {feature}
            </li>
          ))}
        </ul>
      </CardContent>
      <CardFooter className="p-4 flex justify-between items-center border-t">
        <div className="font-semibold">
          {price} <span className="text-muted-foreground font-normal text-sm">/ day</span>
        </div>
        <Button variant="outline" size="sm">
          Add to Booking
        </Button>
      </CardFooter>
    </Card>
  )
}
