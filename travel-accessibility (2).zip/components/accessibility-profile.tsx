"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ShipWheelIcon as Wheelchair, Eye, Ear, Brain, Heart, Save, Plus } from "lucide-react"

export function AccessibilityProfile() {
  const [saved, setSaved] = useState(false)

  const handleSave = () => {
    setSaved(true)
    setTimeout(() => setSaved(false), 3000)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Your Accessibility Profile</CardTitle>
        <CardDescription>
          Save your accessibility needs and preferences for a personalized booking experience.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Accessibility Requirements</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-start space-x-3">
              <Checkbox id="mobility-profile" className="mt-1" />
              <div>
                <Label htmlFor="mobility-profile" className="flex items-center gap-2 text-base font-medium">
                  <Wheelchair className="h-5 w-5" />
                  Mobility Access
                </Label>
                <p className="text-sm text-muted-foreground mt-1">I use a wheelchair or have mobility limitations</p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Checkbox id="visual-profile" className="mt-1" />
              <div>
                <Label htmlFor="visual-profile" className="flex items-center gap-2 text-base font-medium">
                  <Eye className="h-5 w-5" />
                  Visual Impairment
                </Label>
                <p className="text-sm text-muted-foreground mt-1">I have visual impairments or am blind</p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Checkbox id="hearing-profile" className="mt-1" />
              <div>
                <Label htmlFor="hearing-profile" className="flex items-center gap-2 text-base font-medium">
                  <Ear className="h-5 w-5" />
                  Hearing Impairment
                </Label>
                <p className="text-sm text-muted-foreground mt-1">I have hearing impairments or am deaf</p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Checkbox id="cognitive-profile" className="mt-1" />
              <div>
                <Label htmlFor="cognitive-profile" className="flex items-center gap-2 text-base font-medium">
                  <Brain className="h-5 w-5" />
                  Cognitive Needs
                </Label>
                <p className="text-sm text-muted-foreground mt-1">I have cognitive or sensory processing needs</p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Checkbox id="medical-profile" className="mt-1" />
              <div>
                <Label htmlFor="medical-profile" className="flex items-center gap-2 text-base font-medium">
                  <Heart className="h-5 w-5" />
                  Medical Requirements
                </Label>
                <p className="text-sm text-muted-foreground mt-1">I have medical needs that require accommodation</p>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-medium">Specific Accommodation Needs</h3>
          <Textarea
            placeholder="Describe any specific accommodation needs (e.g., roll-in shower, specific bed height, refrigerator for medication)"
            className="min-h-[100px]"
          />
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-medium">Equipment Requirements</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center space-x-2">
              <Checkbox id="wheelchair-rental" />
              <Label htmlFor="wheelchair-rental">Wheelchair Rental</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox id="shower-chair" />
              <Label htmlFor="shower-chair">Shower Chair</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox id="hoist" />
              <Label htmlFor="hoist">Hoist/Patient Lift</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox id="commode" />
              <Label htmlFor="commode">Commode Chair</Label>
            </div>
          </div>
          <Button variant="outline" size="sm" className="mt-2">
            <Plus className="mr-2 h-4 w-4" />
            Add Custom Equipment
          </Button>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-medium">Emergency Contact</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="emergency-name">Contact Name</Label>
              <Input id="emergency-name" placeholder="Full name" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="emergency-phone">Phone Number</Label>
              <Input id="emergency-phone" placeholder="Phone number" type="tel" />
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="emergency-relation">Relationship</Label>
              <Input id="emergency-relation" placeholder="Relationship to you" />
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button onClick={handleSave} className="ml-auto">
          <Save className="mr-2 h-4 w-4" />
          {saved ? "Saved!" : "Save Profile"}
        </Button>
      </CardFooter>
    </Card>
  )
}
