"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ShipWheelIcon as Wheelchair, Eye, Ear, Play, ArrowRight, ArrowLeft } from "lucide-react"

export function VirtualTour() {
  const [currentImage, setCurrentImage] = useState(0)
  const images = [
    {
      src: "/placeholder.svg?height=500&width=800",
      alt: "Hotel entrance with ramp",
      description: "Main entrance with accessible ramp and automatic doors",
      features: ["mobility"],
    },
    {
      src: "/placeholder.svg?height=500&width=800",
      alt: "Accessible hotel room",
      description: "Accessible room with wide doorways and lowered controls",
      features: ["mobility", "visual"],
    },
    {
      src: "/placeholder.svg?height=500&width=800",
      alt: "Accessible bathroom",
      description: "Roll-in shower with grab bars and shower seat",
      features: ["mobility"],
    },
    {
      src: "/placeholder.svg?height=500&width=800",
      alt: "Hotel restaurant",
      description: "Restaurant with accessible tables and large print menus",
      features: ["mobility", "visual"],
    },
  ]

  const nextImage = () => {
    setCurrentImage((prev) => (prev === images.length - 1 ? 0 : prev + 1))
  }

  const prevImage = () => {
    setCurrentImage((prev) => (prev === 0 ? images.length - 1 : prev - 1))
  }

  return (
    <section className="py-12 bg-slate-50">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center text-center space-y-4 mb-10">
          <h2 className="text-2xl md:text-3xl font-bold tracking-tighter">Virtual Accessibility Tours</h2>
          <p className="text-muted-foreground max-w-[700px]">
            Explore accommodations virtually to ensure they meet your accessibility needs before booking.
          </p>
        </div>

        <div className="grid md:grid-cols-[2fr_1fr] gap-8">
          <Card className="overflow-hidden">
            <div className="relative aspect-video">
              <Image
                src={images[currentImage].src || "/placeholder.svg"}
                alt={images[currentImage].alt}
                fill
                className="object-cover"
              />
              <div className="absolute inset-0 flex items-center justify-between p-4">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-10 w-10 rounded-full bg-background/50 backdrop-blur-sm"
                  onClick={prevImage}
                >
                  <ArrowLeft className="h-5 w-5" />
                  <span className="sr-only">Previous</span>
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-10 w-10 rounded-full bg-background/50 backdrop-blur-sm"
                  onClick={nextImage}
                >
                  <ArrowRight className="h-5 w-5" />
                  <span className="sr-only">Next</span>
                </Button>
              </div>
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-4 text-white">
                <p className="font-medium">{images[currentImage].description}</p>
                <div className="flex gap-1 mt-2">
                  {images[currentImage].features.includes("mobility") && (
                    <Badge variant="secondary" className="gap-1 bg-white/20 hover:bg-white/30">
                      <Wheelchair className="h-3 w-3" />
                      Mobility
                    </Badge>
                  )}
                  {images[currentImage].features.includes("visual") && (
                    <Badge variant="secondary" className="gap-1 bg-white/20 hover:bg-white/30">
                      <Eye className="h-3 w-3" />
                      Visual
                    </Badge>
                  )}
                  {images[currentImage].features.includes("hearing") && (
                    <Badge variant="secondary" className="gap-1 bg-white/20 hover:bg-white/30">
                      <Ear className="h-3 w-3" />
                      Hearing
                    </Badge>
                  )}
                </div>
              </div>
              <Button className="absolute top-4 right-4 gap-2" size="sm" variant="secondary">
                <Play className="h-4 w-4" />
                360° Tour
              </Button>
            </div>
            <div className="p-4 flex justify-center gap-2">
              {images.map((_, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  size="icon"
                  className={`h-2 w-2 rounded-full ${currentImage === index ? "bg-primary" : "bg-muted"}`}
                  onClick={() => setCurrentImage(index)}
                >
                  <span className="sr-only">Image {index + 1}</span>
                </Button>
              ))}
            </div>
          </Card>

          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-medium mb-4">Why Virtual Tours Matter</h3>
                <p className="text-muted-foreground mb-6">
                  Virtual tours allow travelers with disabilities to verify accessibility features before booking,
                  reducing uncertainty and ensuring accommodations meet specific needs.
                </p>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <div className="mt-1 h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                      1
                    </div>
                    <div>
                      <p className="font-medium">Verify Accessibility</p>
                      <p className="text-sm text-muted-foreground">See exact measurements and features</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="mt-1 h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                      2
                    </div>
                    <div>
                      <p className="font-medium">Reduce Anxiety</p>
                      <p className="text-sm text-muted-foreground">Know what to expect before arrival</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="mt-1 h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                      3
                    </div>
                    <div>
                      <p className="font-medium">Plan Your Stay</p>
                      <p className="text-sm text-muted-foreground">Identify potential challenges in advance</p>
                    </div>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Tabs defaultValue="hotels">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="hotels">Hotels</TabsTrigger>
                <TabsTrigger value="attractions">Attractions</TabsTrigger>
                <TabsTrigger value="transport">Transport</TabsTrigger>
              </TabsList>
              <TabsContent value="hotels" className="pt-4">
                <p className="text-sm text-muted-foreground mb-4">
                  Explore virtual tours of hotels and accommodations with verified accessibility features.
                </p>
                <Button className="w-full">Browse Accessible Hotels</Button>
              </TabsContent>
              <TabsContent value="attractions" className="pt-4">
                <p className="text-sm text-muted-foreground mb-4">
                  View virtual tours of attractions, museums, and parks with accessibility information.
                </p>
                <Button className="w-full">Explore Accessible Attractions</Button>
              </TabsContent>
              <TabsContent value="transport" className="pt-4">
                <p className="text-sm text-muted-foreground mb-4">
                  See virtual tours of transportation options including accessible vehicles and stations.
                </p>
                <Button className="w-full">View Transport Options</Button>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </section>
  )
}
