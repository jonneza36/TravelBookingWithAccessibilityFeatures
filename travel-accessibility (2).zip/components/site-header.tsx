"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { AccessibilityPanel } from "@/components/accessibility-panel"
import {
  Menu,
  ShipWheelIcon as Wheelchair,
  Settings,
  User,
  Phone,
  Heart,
  SearchIcon,
  Home,
  Map,
  Info,
  LogIn,
} from "lucide-react"
import { useMobile } from "@/hooks/use-mobile"

export function SiteHeader() {
  const isMobile = useMobile()
  const [showAccessibilityPanel, setShowAccessibilityPanel] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          {isMobile && (
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="mr-2" aria-label="Menu">
                  <Menu className="h-5 w-5" />
                  <span className="sr-only">Menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="left">
                <SheetHeader>
                  <SheetTitle>AccessTravel</SheetTitle>
                  <SheetDescription>Accessible travel for everyone</SheetDescription>
                </SheetHeader>
                <nav className="mt-8 flex flex-col gap-4">
                  <Link
                    href="/"
                    className="flex items-center gap-2 text-lg font-medium transition-colors hover:text-primary"
                  >
                    <Home className="h-5 w-5" />
                    Home
                  </Link>
                  <Link
                    href="/destinations"
                    className="flex items-center gap-2 text-lg font-medium transition-colors hover:text-primary"
                  >
                    <Map className="h-5 w-5" />
                    Destinations
                  </Link>
                  <Link
                    href="/equipment-rental"
                    className="flex items-center gap-2 text-lg font-medium transition-colors hover:text-primary"
                  >
                    <Wheelchair className="h-5 w-5" />
                    Equipment Rental
                  </Link>
                  <Link
                    href="/emergency-info"
                    className="flex items-center gap-2 text-lg font-medium transition-colors hover:text-primary"
                  >
                    <Heart className="h-5 w-5" />
                    Emergency Info
                  </Link>
                  <Link
                    href="/support"
                    className="flex items-center gap-2 text-lg font-medium transition-colors hover:text-primary"
                  >
                    <Phone className="h-5 w-5" />
                    Support
                  </Link>
                  <Link
                    href="/about"
                    className="flex items-center gap-2 text-lg font-medium transition-colors hover:text-primary"
                  >
                    <Info className="h-5 w-5" />
                    About Us
                  </Link>
                </nav>
                <div className="mt-8">
                  <Button className="w-full" variant="default">
                    <LogIn className="mr-2 h-4 w-4" /> Sign In
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          )}

          <Link href="/" className="flex items-center gap-2">
            <Wheelchair className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold tracking-tight">AccessTravel</span>
          </Link>
        </div>

        {!isMobile && (
          <NavigationMenu className="hidden md:flex">
            <NavigationMenuList>
              <NavigationMenuItem>
                <Link href="/" legacyBehavior passHref>
                  <NavigationMenuLink className={navigationMenuTriggerStyle()}>Home</NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <NavigationMenuTrigger>Destinations</NavigationMenuTrigger>
                <NavigationMenuContent>
                  <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
                    <li className="row-span-3">
                      <NavigationMenuLink asChild>
                        <a
                          className="flex h-full w-full select-none flex-col justify-end rounded-md bg-gradient-to-b from-muted/50 to-muted p-6 no-underline outline-none focus:shadow-md"
                          href="/"
                        >
                          <Wheelchair className="h-6 w-6" />
                          <div className="mb-2 mt-4 text-lg font-medium">Accessible Destinations</div>
                          <p className="text-sm leading-tight text-muted-foreground">
                            Discover places that prioritize accessibility and inclusion for all travelers.
                          </p>
                        </a>
                      </NavigationMenuLink>
                    </li>
                    <li>
                      <NavigationMenuLink asChild>
                        <a
                          className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground"
                          href="/"
                        >
                          <div className="text-sm font-medium leading-none">Beach Destinations</div>
                          <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                            Accessible beaches and oceanfront resorts.
                          </p>
                        </a>
                      </NavigationMenuLink>
                    </li>
                    <li>
                      <NavigationMenuLink asChild>
                        <a
                          className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground"
                          href="/"
                        >
                          <div className="text-sm font-medium leading-none">City Breaks</div>
                          <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                            Accessible urban accommodations and attractions.
                          </p>
                        </a>
                      </NavigationMenuLink>
                    </li>
                    <li>
                      <NavigationMenuLink asChild>
                        <a
                          className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground"
                          href="/"
                        >
                          <div className="text-sm font-medium leading-none">Nature Retreats</div>
                          <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                            Accessible cabins and outdoor experiences.
                          </p>
                        </a>
                      </NavigationMenuLink>
                    </li>
                  </ul>
                </NavigationMenuContent>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <Link href="/equipment-rental" legacyBehavior passHref>
                  <NavigationMenuLink className={navigationMenuTriggerStyle()}>Equipment Rental</NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <Link href="/emergency-info" legacyBehavior passHref>
                  <NavigationMenuLink className={navigationMenuTriggerStyle()}>Emergency Info</NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <Link href="/support" legacyBehavior passHref>
                  <NavigationMenuLink className={navigationMenuTriggerStyle()}>Support</NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
            </NavigationMenuList>
          </NavigationMenu>
        )}

        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            aria-label="Accessibility Options"
            onClick={() => setShowAccessibilityPanel(true)}
          >
            <Settings className="h-5 w-5" />
            <span className="sr-only">Accessibility Options</span>
          </Button>

          <Button variant="ghost" size="icon" aria-label="Search">
            <SearchIcon className="h-5 w-5" />
            <span className="sr-only">Search</span>
          </Button>

          {!isMobile && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="User Account">
                  <User className="h-5 w-5" />
                  <span className="sr-only">User Account</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>Profile</DropdownMenuItem>
                <DropdownMenuItem>My Bookings</DropdownMenuItem>
                <DropdownMenuItem>Saved Accessibility Settings</DropdownMenuItem>
                <DropdownMenuItem>Sign Out</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}

          {!isMobile && (
            <Button size="sm" className="ml-2">
              Sign In
            </Button>
          )}
        </div>
      </div>

      {showAccessibilityPanel && <AccessibilityPanel onClose={() => setShowAccessibilityPanel(false)} />}
    </header>
  )
}
