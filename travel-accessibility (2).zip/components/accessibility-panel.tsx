"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  X,
  Type,
  Contrast,
  MousePointer,
  Mic,
  Volume2,
  ShipWheelIcon as Wheelchair,
  Eye,
  Ear,
  Brain,
  Heart,
  Save,
} from "lucide-react"

interface AccessibilityPanelProps {
  onClose: () => void
}

export function AccessibilityPanel({ onClose }: AccessibilityPanelProps) {
  const [fontSize, setFontSize] = useState(100)
  const [contrast, setContrast] = useState(false)
  const [reducedMotion, setReducedMotion] = useState(false)
  const [screenReader, setScreenReader] = useState(false)
  const [voiceNavigation, setVoiceNavigation] = useState(false)

  const handleFontSizeChange = (value: number[]) => {
    setFontSize(value[0])
    document.documentElement.style.fontSize = `${value[0]}%`
  }

  const handleContrastChange = (checked: boolean) => {
    setContrast(checked)
    if (checked) {
      document.documentElement.classList.add("high-contrast")
    } else {
      document.documentElement.classList.remove("high-contrast")
    }
  }

  const handleReducedMotionChange = (checked: boolean) => {
    setReducedMotion(checked)
    if (checked) {
      document.documentElement.classList.add("reduced-motion")
    } else {
      document.documentElement.classList.remove("reduced-motion")
    }
  }

  const handleSaveSettings = () => {
    // In a real app, this would save to user preferences
    alert("Your accessibility settings have been saved.")
    onClose()
  }

  return (
    <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm">
      <div className="fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg sm:rounded-lg md:w-full">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Accessibility Settings</h2>
          <Button variant="ghost" size="icon" onClick={onClose} aria-label="Close">
            <X className="h-4 w-4" />
          </Button>
        </div>

        <Tabs defaultValue="display">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="display">Display</TabsTrigger>
            <TabsTrigger value="navigation">Navigation</TabsTrigger>
            <TabsTrigger value="preferences">Preferences</TabsTrigger>
          </TabsList>

          <TabsContent value="display" className="space-y-4 pt-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Type className="h-4 w-4" />
                  <Label htmlFor="font-size">Font Size: {fontSize}%</Label>
                </div>
                <span className="text-sm text-muted-foreground">{fontSize}%</span>
              </div>
              <Slider
                id="font-size"
                min={75}
                max={150}
                step={5}
                value={[fontSize]}
                onValueChange={handleFontSizeChange}
              />
            </div>

            <div className="flex items-center space-x-2">
              <Switch id="contrast" checked={contrast} onCheckedChange={handleContrastChange} />
              <div className="grid gap-1.5 leading-none">
                <Label htmlFor="contrast" className="flex items-center gap-2">
                  <Contrast className="h-4 w-4" />
                  High Contrast Mode
                </Label>
                <p className="text-sm text-muted-foreground">Increases contrast for better readability</p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Switch id="reduced-motion" checked={reducedMotion} onCheckedChange={handleReducedMotionChange} />
              <div className="grid gap-1.5 leading-none">
                <Label htmlFor="reduced-motion" className="flex items-center gap-2">
                  <MousePointer className="h-4 w-4" />
                  Reduced Motion
                </Label>
                <p className="text-sm text-muted-foreground">Minimizes animations and transitions</p>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="navigation" className="space-y-4 pt-4">
            <div className="flex items-center space-x-2">
              <Switch id="screen-reader" checked={screenReader} onCheckedChange={setScreenReader} />
              <div className="grid gap-1.5 leading-none">
                <Label htmlFor="screen-reader" className="flex items-center gap-2">
                  <Volume2 className="h-4 w-4" />
                  Screen Reader Optimized
                </Label>
                <p className="text-sm text-muted-foreground">Enhances compatibility with screen readers</p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Switch id="voice-navigation" checked={voiceNavigation} onCheckedChange={setVoiceNavigation} />
              <div className="grid gap-1.5 leading-none">
                <Label htmlFor="voice-navigation" className="flex items-center gap-2">
                  <Mic className="h-4 w-4" />
                  Voice Navigation
                </Label>
                <p className="text-sm text-muted-foreground">Navigate the site using voice commands</p>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="preferences" className="space-y-4 pt-4">
            <div className="space-y-4">
              <h3 className="text-sm font-medium">Accessibility Needs</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Switch id="mobility-pref" />
                  <Label htmlFor="mobility-pref" className="flex items-center gap-2 text-sm">
                    <Wheelchair className="h-4 w-4" />
                    Mobility
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch id="visual-pref" />
                  <Label htmlFor="visual-pref" className="flex items-center gap-2 text-sm">
                    <Eye className="h-4 w-4" />
                    Visual
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch id="hearing-pref" />
                  <Label htmlFor="hearing-pref" className="flex items-center gap-2 text-sm">
                    <Ear className="h-4 w-4" />
                    Hearing
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch id="cognitive-pref" />
                  <Label htmlFor="cognitive-pref" className="flex items-center gap-2 text-sm">
                    <Brain className="h-4 w-4" />
                    Cognitive
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch id="medical-pref" />
                  <Label htmlFor="medical-pref" className="flex items-center gap-2 text-sm">
                    <Heart className="h-4 w-4" />
                    Medical
                  </Label>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSaveSettings}>
            <Save className="mr-2 h-4 w-4" />
            Save Settings
          </Button>
        </div>
      </div>
    </div>
  )
}
