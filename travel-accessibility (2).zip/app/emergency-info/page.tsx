"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { SiteHeader } from "@/components/site-header"
import { Heart, Phone, AlertCircle, Plus, Save, FileText, Download } from "lucide-react"

export default function EmergencyInfoPage() {
  const [saved, setSaved] = useState(false)

  const handleSave = () => {
    setSaved(true)
    setTimeout(() => setSaved(false), 3000)
  }

  return (
    <>
      <SiteHeader />
      <main className="container py-10 px-4 md:px-6">
        <div className="flex flex-col gap-2 mb-8">
          <h1 className="text-3xl font-bold tracking-tight">Emergency Information</h1>
          <p className="text-muted-foreground">
            Manage your emergency contacts and medical information for safer travel.
          </p>
        </div>

        <Tabs defaultValue="contacts" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="contacts">Emergency Contacts</TabsTrigger>
            <TabsTrigger value="medical">Medical Information</TabsTrigger>
            <TabsTrigger value="documents">Important Documents</TabsTrigger>
          </TabsList>

          <TabsContent value="contacts" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Phone className="h-5 w-5 text-primary" />
                  Primary Emergency Contact
                </CardTitle>
                <CardDescription>
                  This person will be contacted first in case of an emergency during your travels.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="primary-name">Full Name</Label>
                    <Input id="primary-name" placeholder="Full name" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="primary-relationship">Relationship</Label>
                    <Input id="primary-relationship" placeholder="Relationship to you" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="primary-phone">Phone Number</Label>
                    <Input id="primary-phone" placeholder="Phone number" type="tel" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="primary-email">Email</Label>
                    <Input id="primary-email" placeholder="Email address" type="email" />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="primary-notes">Additional Notes</Label>
                    <Textarea id="primary-notes" placeholder="Any additional information" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Phone className="h-5 w-5 text-primary" />
                  Secondary Emergency Contact
                </CardTitle>
                <CardDescription>
                  This person will be contacted if your primary contact cannot be reached.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="secondary-name">Full Name</Label>
                    <Input id="secondary-name" placeholder="Full name" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="secondary-relationship">Relationship</Label>
                    <Input id="secondary-relationship" placeholder="Relationship to you" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="secondary-phone">Phone Number</Label>
                    <Input id="secondary-phone" placeholder="Phone number" type="tel" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="secondary-email">Email</Label>
                    <Input id="secondary-email" placeholder="Email address" type="email" />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="secondary-notes">Additional Notes</Label>
                    <Textarea id="secondary-notes" placeholder="Any additional information" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="flex justify-end">
              <Button onClick={handleSave}>
                <Save className="mr-2 h-4 w-4" />
                {saved ? "Saved!" : "Save Emergency Contacts"}
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="medical" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-primary" />
                  Medical Information
                </CardTitle>
                <CardDescription>
                  This information will be available to emergency services if needed during your travels.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Medical Conditions</h3>
                  <Textarea
                    placeholder="List any medical conditions, disabilities, or chronic illnesses"
                    className="min-h-[100px]"
                  />
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Medications</h3>
                  <Textarea placeholder="List current medications, dosages, and schedules" className="min-h-[100px]" />
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Allergies</h3>
                  <Textarea
                    placeholder="List any allergies (medications, food, environmental) and reactions"
                    className="min-h-[100px]"
                  />
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Medical Devices</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center space-x-2">
                      <Switch id="pacemaker" />
                      <Label htmlFor="pacemaker">Pacemaker</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch id="insulin-pump" />
                      <Label htmlFor="insulin-pump">Insulin Pump</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch id="cpap" />
                      <Label htmlFor="cpap">CPAP Machine</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch id="hearing-aid" />
                      <Label htmlFor="hearing-aid">Hearing Aid</Label>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" className="mt-2">
                    <Plus className="mr-2 h-4 w-4" />
                    Add Other Medical Device
                  </Button>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Healthcare Provider Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="doctor-name">Primary Doctor</Label>
                      <Input id="doctor-name" placeholder="Doctor's name" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="doctor-phone">Phone Number</Label>
                      <Input id="doctor-phone" placeholder="Doctor's phone number" type="tel" />
                    </div>
                    <div className="space-y-2 md:col-span-2">
                      <Label htmlFor="insurance">Insurance Information</Label>
                      <Input id="insurance" placeholder="Insurance provider and policy number" />
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <div className="flex items-center space-x-2 ml-auto">
                  <Switch id="share-medical" />
                  <Label htmlFor="share-medical">Share with accommodation providers in case of emergency</Label>
                </div>
              </CardFooter>
            </Card>

            <div className="flex justify-end">
              <Button onClick={handleSave}>
                <Save className="mr-2 h-4 w-4" />
                {saved ? "Saved!" : "Save Medical Information"}
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="documents" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-primary" />
                  Important Documents
                </CardTitle>
                <CardDescription>
                  Store digital copies of important documents for easy access during your travels.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-medium">Passport</h3>
                    <Button variant="outline" size="sm">
                      <Plus className="mr-2 h-4 w-4" />
                      Upload
                    </Button>
                  </div>
                  <div className="border rounded-md p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <FileText className="h-8 w-8 text-muted-foreground" />
                      <div>
                        <p className="font-medium">passport.pdf</p>
                        <p className="text-sm text-muted-foreground">Uploaded on May 10, 2023</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">
                      <Download className="h-4 w-4" />
                      <span className="sr-only">Download</span>
                    </Button>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-medium">Insurance Card</h3>
                    <Button variant="outline" size="sm">
                      <Plus className="mr-2 h-4 w-4" />
                      Upload
                    </Button>
                  </div>
                  <div className="border rounded-md p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <FileText className="h-8 w-8 text-muted-foreground" />
                      <div>
                        <p className="font-medium">insurance_card.jpg</p>
                        <p className="text-sm text-muted-foreground">Uploaded on May 12, 2023</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">
                      <Download className="h-4 w-4" />
                      <span className="sr-only">Download</span>
                    </Button>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-medium">Prescription Documentation</h3>
                    <Button variant="outline" size="sm">
                      <Plus className="mr-2 h-4 w-4" />
                      Upload
                    </Button>
                  </div>
                  <div className="border rounded-md p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <FileText className="h-8 w-8 text-muted-foreground" />
                      <div>
                        <p className="font-medium">prescriptions.pdf</p>
                        <p className="text-sm text-muted-foreground">Uploaded on May 15, 2023</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">
                      <Download className="h-4 w-4" />
                      <span className="sr-only">Download</span>
                    </Button>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-medium">Doctor's Note</h3>
                    <Button variant="outline" size="sm">
                      <Plus className="mr-2 h-4 w-4" />
                      Upload
                    </Button>
                  </div>
                  <div className="border border-dashed rounded-md p-8 flex flex-col items-center justify-center text-center">
                    <FileText className="h-10 w-10 text-muted-foreground mb-2" />
                    <p className="font-medium">No document uploaded</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Upload a doctor's note or medical necessity letter
                    </p>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <div className="flex items-center space-x-2 ml-auto">
                  <AlertCircle className="h-4 w-4 text-muted-foreground" />
                  <p className="text-sm text-muted-foreground">Documents are encrypted and only accessible to you</p>
                </div>
              </CardFooter>
            </Card>

            <div className="flex justify-end">
              <Button onClick={handleSave}>
                <Save className="mr-2 h-4 w-4" />
                {saved ? "Saved!" : "Save Document Settings"}
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </>
  )
}
