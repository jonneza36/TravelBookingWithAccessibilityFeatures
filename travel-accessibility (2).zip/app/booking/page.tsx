"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { SiteHeader } from "@/components/site-header"
import {
  ShipWheelIcon as Wheelchair,
  Eye,
  Ear,
  Brain,
  Heart,
  Calendar,
  Users,
  CreditCard,
  CheckCircle,
  ArrowRight,
  ArrowLeft,
} from "lucide-react"

export default function BookingPage() {
  const [step, setStep] = useState(1)
  const totalSteps = 4

  const nextStep = () => {
    if (step < totalSteps) {
      setStep(step + 1)
    }
  }

  const prevStep = () => {
    if (step > 1) {
      setStep(step - 1)
    }
  }

  return (
    <>
      <SiteHeader />
      <main className="container py-10 px-4 md:px-6">
        <div className="flex flex-col gap-2 mb-8">
          <h1 className="text-3xl font-bold tracking-tight">Book Your Accessible Stay</h1>
          <p className="text-muted-foreground">Complete your booking with detailed accessibility requirements.</p>
        </div>

        <div className="mb-8">
          <div className="flex justify-between">
            {Array.from({ length: totalSteps }).map((_, i) => (
              <div
                key={i}
                className={`flex flex-col items-center ${
                  i + 1 < step ? "text-primary" : i + 1 === step ? "text-primary" : "text-muted-foreground"
                }`}
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 ${
                    i + 1 < step
                      ? "bg-primary text-primary-foreground"
                      : i + 1 === step
                        ? "border-2 border-primary"
                        : "border-2 border-muted"
                  }`}
                >
                  {i + 1 < step ? (
                    <CheckCircle className="h-5 w-5" />
                  ) : (
                    <span className="text-sm font-medium">{i + 1}</span>
                  )}
                </div>
                <span className="text-sm font-medium hidden md:block">
                  {i === 0
                    ? "Accommodation Details"
                    : i === 1
                      ? "Accessibility Needs"
                      : i === 2
                        ? "Guest Information"
                        : "Payment"}
                </span>
              </div>
            ))}
          </div>
          <div className="mt-4 h-2 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-primary transition-all duration-300 ease-in-out"
              style={{ width: `${(step / totalSteps) * 100}%` }}
            ></div>
          </div>
        </div>

        {step === 1 && (
          <Card>
            <CardHeader>
              <CardTitle>Accommodation Details</CardTitle>
              <CardDescription>Confirm your stay details and preferences.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="check-in">Check-in Date</Label>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <Input id="check-in" type="date" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="check-out">Check-out Date</Label>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <Input id="check-out" type="date" />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="guests">Number of Guests</Label>
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <Select>
                    <SelectTrigger id="guests">
                      <SelectValue placeholder="Select number of guests" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 Guest</SelectItem>
                      <SelectItem value="2">2 Guests</SelectItem>
                      <SelectItem value="3">3 Guests</SelectItem>
                      <SelectItem value="4">4 Guests</SelectItem>
                      <SelectItem value="5">5+ Guests</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Room Type</Label>
                <RadioGroup defaultValue="accessible">
                  <div className="flex items-start space-x-3 space-y-0">
                    <RadioGroupItem value="accessible" id="accessible-room" />
                    <div className="grid gap-1.5 leading-none">
                      <Label htmlFor="accessible-room" className="font-medium">
                        Accessible Room
                      </Label>
                      <p className="text-sm text-muted-foreground">
                        Fully accessible room with roll-in shower, grab bars, and lowered amenities
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3 space-y-0 mt-3">
                    <RadioGroupItem value="partially" id="partially-room" />
                    <div className="grid gap-1.5 leading-none">
                      <Label htmlFor="partially-room" className="font-medium">
                        Partially Accessible Room
                      </Label>
                      <p className="text-sm text-muted-foreground">
                        Room with some accessibility features like grab bars and wider doorways
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3 space-y-0 mt-3">
                    <RadioGroupItem value="standard" id="standard-room" />
                    <div className="grid gap-1.5 leading-none">
                      <Label htmlFor="standard-room" className="font-medium">
                        Standard Room
                      </Label>
                      <p className="text-sm text-muted-foreground">
                        Standard room without specific accessibility features
                      </p>
                    </div>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label>Bed Preference</Label>
                <RadioGroup defaultValue="king">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="king" id="king-bed" />
                    <Label htmlFor="king-bed">King Bed</Label>
                  </div>
                  <div className="flex items-center space-x-2 mt-2">
                    <RadioGroupItem value="queen" id="queen-bed" />
                    <Label htmlFor="queen-bed">Queen Bed</Label>
                  </div>
                  <div className="flex items-center space-x-2 mt-2">
                    <RadioGroupItem value="twin" id="twin-bed" />
                    <Label htmlFor="twin-bed">Twin Beds</Label>
                  </div>
                </RadioGroup>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" disabled>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back
              </Button>
              <Button onClick={nextStep}>
                Continue
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        )}

        {step === 2 && (
          <Card>
            <CardHeader>
              <CardTitle>Accessibility Requirements</CardTitle>
              <CardDescription>Tell us about your specific accessibility needs.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Accessibility Needs</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-start space-x-3">
                    <Checkbox id="mobility-booking" className="mt-1" />
                    <div>
                      <Label htmlFor="mobility-booking" className="flex items-center gap-2 text-base font-medium">
                        <Wheelchair className="h-5 w-5" />
                        Mobility Access
                      </Label>
                      <p className="text-sm text-muted-foreground mt-1">
                        I use a wheelchair or have mobility limitations
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <Checkbox id="visual-booking" className="mt-1" />
                    <div>
                      <Label htmlFor="visual-booking" className="flex items-center gap-2 text-base font-medium">
                        <Eye className="h-5 w-5" />
                        Visual Impairment
                      </Label>
                      <p className="text-sm text-muted-foreground mt-1">I have visual impairments or am blind</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <Checkbox id="hearing-booking" className="mt-1" />
                    <div>
                      <Label htmlFor="hearing-booking" className="flex items-center gap-2 text-base font-medium">
                        <Ear className="h-5 w-5" />
                        Hearing Impairment
                      </Label>
                      <p className="text-sm text-muted-foreground mt-1">I have hearing impairments or am deaf</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <Checkbox id="cognitive-booking" className="mt-1" />
                    <div>
                      <Label htmlFor="cognitive-booking" className="flex items-center gap-2 text-base font-medium">
                        <Brain className="h-5 w-5" />
                        Cognitive Needs
                      </Label>
                      <p className="text-sm text-muted-foreground mt-1">I have cognitive or sensory processing needs</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <Checkbox id="medical-booking" className="mt-1" />
                    <div>
                      <Label htmlFor="medical-booking" className="flex items-center gap-2 text-base font-medium">
                        <Heart className="h-5 w-5" />
                        Medical Requirements
                      </Label>
                      <p className="text-sm text-muted-foreground mt-1">
                        I have medical needs that require accommodation
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Room Requirements</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="roll-in-shower" />
                    <Label htmlFor="roll-in-shower">Roll-in shower</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="grab-bars" />
                    <Label htmlFor="grab-bars">Bathroom grab bars</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="lowered-bed" />
                    <Label htmlFor="lowered-bed">Lowered bed height</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="visual-alerts" />
                    <Label htmlFor="visual-alerts">Visual fire alarms</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="ground-floor" />
                    <Label htmlFor="ground-floor">Ground floor room</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="near-elevator" />
                    <Label htmlFor="near-elevator">Near elevator</Label>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Equipment Rental</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="shower-chair-rental" />
                    <Label htmlFor="shower-chair-rental">Shower chair</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="commode-rental" />
                    <Label htmlFor="commode-rental">Commode chair</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="hoist-rental" />
                    <Label htmlFor="hoist-rental">Patient lift/hoist</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="wheelchair-rental" />
                    <Label htmlFor="wheelchair-rental">Wheelchair</Label>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="specific-needs">Additional Accessibility Requirements</Label>
                <Textarea
                  id="specific-needs"
                  placeholder="Please describe any other specific accessibility needs or requirements"
                  className="min-h-[100px]"
                />
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={prevStep}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back
              </Button>
              <Button onClick={nextStep}>
                Continue
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        )}

        {step === 3 && (
          <Card>
            <CardHeader>
              <CardTitle>Guest Information</CardTitle>
              <CardDescription>Provide your personal details for the booking.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="first-name">First Name</Label>
                  <Input id="first-name" placeholder="First name" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="last-name">Last Name</Label>
                  <Input id="last-name" placeholder="Last name" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input id="email" type="email" placeholder="Email address" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input id="phone" type="tel" placeholder="Phone number" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="arrival-time">Estimated Arrival Time</Label>
                <Select>
                  <SelectTrigger id="arrival-time">
                    <SelectValue placeholder="Select arrival time" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="morning">Morning (8am - 12pm)</SelectItem>
                    <SelectItem value="afternoon">Afternoon (12pm - 4pm)</SelectItem>
                    <SelectItem value="evening">Evening (4pm - 8pm)</SelectItem>
                    <SelectItem value="night">Night (After 8pm)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="special-requests">Special Requests</Label>
                <Textarea
                  id="special-requests"
                  placeholder="Any special requests or information the hotel should know"
                  className="min-h-[100px]"
                />
              </div>

              <div className="flex items-start space-x-3">
                <Checkbox id="share-info" className="mt-1" />
                <div>
                  <Label htmlFor="share-info" className="text-base">
                    Share accessibility needs with accommodation
                  </Label>
                  <p className="text-sm text-muted-foreground mt-1">
                    Allow us to share your accessibility requirements with the accommodation to ensure they can prepare
                    for your stay
                  </p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={prevStep}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back
              </Button>
              <Button onClick={nextStep}>
                Continue to Payment
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        )}

        {step === 4 && (
          <Card>
            <CardHeader>
              <CardTitle>Payment Information</CardTitle>
              <CardDescription>Complete your booking with payment details.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="card-name">Name on Card</Label>
                <Input id="card-name" placeholder="Name as it appears on card" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="card-number">Card Number</Label>
                <div className="flex items-center gap-2">
                  <CreditCard className="h-4 w-4 text-muted-foreground" />
                  <Input id="card-number" placeholder="Card number" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="expiry">Expiry Date</Label>
                  <Input id="expiry" placeholder="MM/YY" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cvc">CVC</Label>
                  <Input id="cvc" placeholder="CVC" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="billing-address">Billing Address</Label>
                <Textarea id="billing-address" placeholder="Enter your billing address" />
              </div>

              <div className="flex items-start space-x-3">
                <Checkbox id="terms" className="mt-1" />
                <div>
                  <Label htmlFor="terms" className="text-base">
                    I agree to the terms and conditions
                  </Label>
                  <p className="text-sm text-muted-foreground mt-1">
                    I have read and agree to the booking terms, cancellation policy, and accessibility accommodation
                    policy
                  </p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={prevStep}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back
              </Button>
              <Button>
                Complete Booking
                <CheckCircle className="ml-2 h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        )}
      </main>
    </>
  )
}
